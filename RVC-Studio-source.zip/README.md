# RVC Studio

基于 [RVC WebUI](https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI) 的 Windows 桌面变声工作室：Qt 界面、后台模型加载、明确的音频设备路由，以及按需打开的完整音频 WebUI。

本仓库公开源码，不包含 Python 便携运行时、CUDA 库、模型权重、索引、录音或 FFmpeg，也不是下载后即可直接运行的完整软件安装包。

## 功能

- 实时变声、输入监听；模型/索引选择、音调、声线、响度、索引混合。
- 设备刷新、主机 API、WASAPI 独占、模型/设备采样率、PM/RMVPE/FCPE、双向降噪、缓冲参数。
- 输入/输出电平、推理耗时、预计延迟、音频异常统计。
- 模型后台加载，音频回调不直接更新界面，停止后可复用模型。
- Windows pythonw 与可选 EXE 启动器不显示控制台；错误写入用户日志。
- 内嵌完整工作室，保留离线转换、分离、训练、特征提取、索引、模型工具。
- 设置和 Numba 缓存保存在用户可写目录。

核心 RVC、音高提取、SOLA、降噪和重采样沿用现有实现。主要重构桌面层、引擎控制与设备绑定，不声称所有底层代码都已重写或所有模型均提速。

## 环境

Windows 10/11、Python 3.12 x64。桌面程序以 Windows 为目标。推荐有兼容驱动的 NVIDIA GPU，也提供 CPU/DirectML 依赖方案。FFmpeg/FFprobe 需放在项目根目录或加入 PATH。聊天软件变声需要自行安装、配置虚拟声卡。

## 安装

### 已有完整 RVC 便携目录

先备份原文件，将源码合并到完整便携目录，保留 runtime、assets、logs、模型和 FFmpeg，然后安装新增桌面依赖：

```powershell
.\runtime\python.exe -I -m pip install -r requirements-desktop.txt
```

运行 go-realtime_gui.bat，或构建后双击 RVC Studio.exe。旧版 realtime_gui.py 和独立 webui.py 仍保留。

### 从源码配置

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
```

按硬件选择一套依赖，文件名保留原拼写 requirments：

| 环境 | 文件 | 安装方式 |
| --- | --- | --- |
| CPU / DirectML | requirments_cpu_py312.txt | 按文件头说明安装 |
| CUDA 11.8 | requirments_cu118_py312.txt | 先装匹配 Torch/Torchaudio，再安装该文件 |
| CUDA 12.8 | requirments_cu128_py312.txt | 先装匹配 Torch/Torchaudio，再安装该文件 |

CUDA 11.8 示例：

```powershell
.\.venv\Scripts\python.exe -m pip install torch==2.7.1+cu118 torchaudio==2.7.1+cu118 --index-url https://download.pytorch.org/whl/cu118
.\.venv\Scripts\python.exe -m pip install -r requirments_cu118_py312.txt
.\.venv\Scripts\python.exe -m pip install -r requirements-desktop.txt
```

现有依赖文件保留原镜像设置；替换镜像时保持版本和两阶段安装顺序。setup.sh cpu|cu118|cu128 提供虚拟环境安装脚本，需在 Git Bash/Linux shell 中自行运行，Windows 桌面功能仍以 Windows 为准。

补齐模型后，用 .venv\Scripts\python.exe desktop_app.py 诊断启动，或运行 go-realtime_gui.bat 隐藏控制台。

## 模型资源

基础资源参考 [RVC 资源仓库](https://huggingface.co/lj1995/VoiceConversionWebUI/tree/main)。本版 HuBERT 使用 Transformers 格式，参见 infer/hubert.py，确保模型权重和配置匹配。

```text
assets/
  hubert_base/       # config.json、preprocessor_config.json、模型权重
  rmvpe/            # 使用 RMVPE 时需要 rmvpe.pt
  weights/          # 有权使用的音色 .pth 模型
  indices/          # 可选 .index
  pretrained/       # v1 训练权重
  pretrained_v2/    # v2 训练权重
  pymss_weights/    # 分离模型
logs/               # 训练输出及可选索引
```

源码中的 JSON/YAML 不能代替权重。训练、分离和音高算法可能需要各自资源；根据页面和日志补齐。预训练底模不能当成可直接试听的音色模型。

## 使用

1. 选择音色 .pth 和可选配套 .index。
2. 选择真实麦克风和明确的输出设备，点击开始变声。
3. 直接监听时输出选耳机；发送给聊天软件时选虚拟声卡播放端。
4. Voicemeeter 示例：RVC 输出选 Voicemeeter Input，Voicemeeter 硬件输出选耳机，聊天软件输入选 Voicemeeter Output。

热插拔后先停止转换，再刷新、重选设备。出现接缝杂音时可先恢复 0.13 秒采样块、0.04–0.08 秒交叉淡化，关闭叠加降噪比较，不要一味缩小缓冲。

训练位于音频工作室的训练页。使用单人、清晰、无伴奏且有权使用的目标音色素材，训练后加载推理模型及索引。完整训练不属于轻量验证范围。

## 构建 EXE

```powershell
powershell -File .\build-desktop.ps1
```

脚本使用本机 .NET Framework C# 编译器生成小型 Windows 启动器，不把 Torch、CUDA 或模型打包进 EXE。EXE 必须与源码和 runtime\pythonw.exe 或 .venv\Scripts\pythonw.exe 保留在项目根目录。

## 配置、日志与许可

用户数据在 %LOCALAPPDATA%\RVCStudio，包括 settings.json、desktop.log、runtime.log、studio.log。无需账号、密钥或 .env 文件；.env.example 仅记录可选变量示例，程序不自动读取它。

开发参见 [CONTRIBUTING.md](CONTRIBUTING.md) 和 [CLAUDE.md](CLAUDE.md)。原说明保存在 [docs/UPSTREAM_README.md](docs/UPSTREAM_README.md)。沿用 [MIT](LICENSE)，保留上游和第三方声明。源码许可不自动授予第三方模型、声音或训练素材的使用权。
