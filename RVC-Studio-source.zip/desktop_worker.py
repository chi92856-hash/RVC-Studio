"""Qt control thread. Heavy ML imports happen after the first window paint."""
import logging
import os
import queue
import time
from PySide6.QtCore import QThread, Signal

class EngineWorker(QThread):
    ready = Signal(object)
    state = Signal(str, object)
    failed = Signal(str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.commands = queue.Queue()
        self.settings = settings
        self.engine = None

    def submit(self, command, payload=None):
        self.commands.put((command, payload))

    def run(self):
        try:
            os.environ['RVC_CUDA_GRAPH'] = '1' if self.settings.get('cuda_graph', True) else '0'
            self.state.emit('loading', '正在加载音频引擎与 GPU…')
            started = time.perf_counter()
            from desktop_engine import Engine
            # Suppress high-frequency legacy inference logs while keeping failures.
            from infer import rtrvc
            rtrvc.printt = lambda *args: None
            self.engine = Engine()
            self.ready.emit(self.engine.records)
            self.state.emit('ready', dict(device=str(self.engine.config.device),
                                          seconds=time.perf_counter()-started))
        except Exception as error:
            logging.exception('Engine initialization failed')
            self.failed.emit(str(error))
            return
        while True:
            command, payload = self.commands.get()
            try:
                if command == 'quit':
                    self.engine.stop_stream()
                    return
                if command == 'start':
                    self.state.emit('starting', '正在加载模型并预热…')
                    stats = self.engine.start(payload)
                    self.state.emit('running', stats)
                elif command == 'stop':
                    self.engine.stop_stream()
                    self.state.emit('stopped', None)
                elif command == 'refresh':
                    self.ready.emit(self.engine.refresh())
                    self.state.emit('stopped', None)
                elif command == 'change':
                    self.engine.change(*payload)
            except Exception as error:
                if command == 'start':
                    self.engine.stop_stream()
                logging.exception('Engine command %s failed', command)
                self.failed.emit(str(error))
