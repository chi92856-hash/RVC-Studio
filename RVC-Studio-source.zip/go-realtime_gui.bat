@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "%~dp0desktop_app.py" goto missing
if exist "%~dp0runtime\pythonw.exe" (
    start "" "%~dp0runtime\pythonw.exe" -I "%~dp0desktop_app.py"
    exit /b
)
if exist "%~dp0.venv\Scripts\pythonw.exe" (
    start "" "%~dp0.venv\Scripts\pythonw.exe" "%~dp0desktop_app.py"
    exit /b
)
:missing
echo 缺少 desktop_app.py 或 Python 环境，请先按 README 安装依赖。
echo 支持 runtime\pythonw.exe 或 .venv\Scripts\pythonw.exe。
echo 启动错误可用对应 python.exe 运行 desktop_app.py 查看。
pause
exit /b 1
