---
name: 功能建议
about: 描述希望解决的问题
title: ''
labels: enhancement
assignees: ''
---

## 需要解决的问题

## 期望操作方式

## 可接受的替代方案与限制
