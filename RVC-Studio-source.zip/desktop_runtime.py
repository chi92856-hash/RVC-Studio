"""Lightweight, Qt-independent configuration and device identity helpers."""
import json
import os
import sys
from pathlib import Path

ROOT = Path(os.environ.get('RVC_APP_ROOT', Path(__file__).resolve().parent))
DATA = Path(os.environ.get('LOCALAPPDATA', str(ROOT))) / 'RVCStudio'
DEFAULTS = dict(
    pth_path='', index_path='', sg_hostapi='MME', sg_wasapi_exclusive=False,
    sg_input_device='', sg_output_device='', sr_type='sr_device', threhold=-60.,
    pitch=0., formant=0., rms_mix_rate=.5, index_rate=0., block_time=.13,
    crossfade_length=.08, extra_time=2., f0method='rmvpe',
    I_noise_reduce=False, O_noise_reduce=False, function='vc', cuda_graph=True,
)

def python_executable(windowed=False):
    """Use the portable interpreter when present, otherwise the active environment."""
    name = 'pythonw.exe' if windowed and os.name == 'nt' else 'python.exe'
    portable = ROOT / 'runtime' / name
    if portable.is_file():
        return portable
    current = Path(sys.executable)
    if os.name == 'nt':
        candidate = current.with_name(name)
        if candidate.is_file():
            return candidate
    return current

def prepare_environment():
    DATA.mkdir(parents=True, exist_ok=True)
    cache = DATA / 'numba-cache'
    cache.mkdir(exist_ok=True)
    os.environ['NUMBA_CACHE_DIR'] = str(cache)
    os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
    os.environ.setdefault('OMP_NUM_THREADS', '4')
    os.environ['PATH'] = str(ROOT / 'runtime') + os.pathsep + os.environ.get('PATH', '')
    os.environ['GRADIO_ANALYTICS_ENABLED'] = 'False'
    os.environ['NO_PROXY'] = 'localhost,127.0.0.1,::1'
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    os.chdir(ROOT)

def load_settings():
    data = DEFAULTS.copy()
    for path in (ROOT / 'configs' / 'config.json', DATA / 'settings.json'):
        try:
            value = json.loads(path.read_text(encoding='utf-8-sig'))
            if isinstance(value, dict):
                data.update({k: v for k, v in value.items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass
    return data

def save_settings(data):
    # Replace atomically: a crash cannot truncate the last usable configuration.
    DATA.mkdir(parents=True, exist_ok=True)
    path = DATA / 'settings.json'
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)

def device_records(devices, hostapis):
    """PortAudio indices are the enumeration positions, never a name lookup."""
    return [dict(id=i, name=d['name'], hostapi=hostapis[d['hostapi']]['name'],
                 inputs=int(d['max_input_channels']), outputs=int(d['max_output_channels']),
                 rate=int(d['default_samplerate'])) for i, d in enumerate(devices)]

def resolve_device(records, name, hostapi, direction):
    matches = [d for d in records if d['hostapi'] == hostapi
               and d[direction] > 0 and d['name'] == name]
    if len(matches) != 1:
        raise ValueError('音频设备已改变或名称重复，请刷新设备并重新选择。')
    return matches[0]

def validate_settings(values):
    v = DEFAULTS | values
    limits = dict(pitch=(-24,24), formant=(-2,2), threhold=(-60,0),
                  rms_mix_rate=(0,1), index_rate=(0,1), block_time=(.03,1.5),
                  crossfade_length=(.01,.5), extra_time=(.05,5))
    for key, (lo, hi) in limits.items():
        number = float(v[key])
        if not lo <= number <= hi:
            raise ValueError(f'{key} 超出有效范围 {lo}–{hi}')
        v[key] = number
    if v['f0method'] not in ('pm','rmvpe','fcpe') or v['sr_type'] not in ('sr_model','sr_device'):
        raise ValueError('音高算法或采样率设置无效')
    model = Path(v['pth_path'])
    if not model.is_file() or model.suffix.lower() != '.pth':
        raise ValueError('请选择有效的 .pth 声音模型')
    if v['index_rate'] > 0:
        index = Path(v['index_path'])
        if not index.is_file() or index.suffix.lower() != '.index':
            raise ValueError('启用索引检索时需要有效的 .index 文件')
    return v
