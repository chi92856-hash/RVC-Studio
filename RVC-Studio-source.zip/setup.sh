#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
variant="${1:-cpu}"
case "$variant" in cpu|cu118|cu128) ;; *) echo 'Usage: ./setup.sh cpu|cu118|cu128' >&2; exit 2;; esac
python_bin="${PYTHON:-python3.12}"
"$python_bin" -c 'import sys; assert sys.version_info[:2] == (3, 12), "Python 3.12 is required"'
"$python_bin" -m venv .venv
if [[ -x .venv/Scripts/python.exe ]]; then
    python_env=.venv/Scripts/python.exe
else
    python_env=.venv/bin/python
fi
"$python_env" -m pip install --upgrade pip
if [[ "$variant" != cpu ]]; then
    "$python_env" -m pip install "torch==2.7.1+$variant" "torchaudio==2.7.1+$variant" --index-url "https://download.pytorch.org/whl/$variant"
fi
"$python_env" -m pip install -r "requirments_${variant}_py312.txt"
"$python_env" -m pip install -r requirements-desktop.txt
printf '%s\n' 'Dependencies installed. Supply model weights and FFmpeg separately; see README.md.'
