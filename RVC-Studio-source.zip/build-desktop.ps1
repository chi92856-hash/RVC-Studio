$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler)) {
    $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework\v4.0.30319\csc.exe'
}
if (-not (Test-Path -LiteralPath $compiler)) {
    throw '未找到 .NET Framework C# 编译器。请安装相应开发工具，或运行 go-realtime_gui.bat。'
}
& $compiler /nologo /target:winexe /reference:System.Windows.Forms.dll "/out:$projectRoot\RVC Studio.exe" (Join-Path $projectRoot 'RVCStudio.cs')
if ($LASTEXITCODE -ne 0) { throw 'RVC Studio 启动器构建失败。' }
Write-Host '已生成 RVC Studio.exe。仍需 Python 环境、依赖及模型。'
