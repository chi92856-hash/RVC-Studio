"""Run the complete existing WebUI privately, without console or browser."""
import os
import runpy
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root))
from desktop_runtime import DATA, prepare_environment, python_executable
prepare_environment()
os.environ['RVC_DESKTOP_STUDIO'] = '1'
os.environ['RVC_DESKTOP_TEMP'] = str(DATA / 'studio-temp')
os.environ['GRADIO_ANALYTICS_ENABLED'] = 'False'
os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['TRANSFORMERS_OFFLINE'] = '1'
log = open(DATA / 'studio.log', 'a', encoding='utf-8', buffering=1)
sys.stdout = sys.stderr = log
# All existing preprocessing/training/separation subprocesses inherit no console.
import subprocess
_popen = subprocess.Popen
class HiddenPopen(_popen):
    # asyncio subclasses Popen during import; preserve the class contract.
    def __init__(self, *args, **kwargs):
        kwargs['creationflags'] = kwargs.get('creationflags', 0) | subprocess.CREATE_NO_WINDOW
        if kwargs.get('stdout') is None:
            kwargs['stdout'] = log
        if kwargs.get('stderr') is None:
            kwargs['stderr'] = log
        super().__init__(*args, **kwargs)
subprocess.Popen = HiddenPopen
sys.argv = [str(root / 'webui.py'), '--port', sys.argv[1], '--noautoopen',
            '--pycmd', str(python_executable())]
runpy.run_path(str(root / 'webui.py'), run_name='__main__')
