using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class Launcher {
    [STAThread]
    static void Main() {
        string root = AppDomain.CurrentDomain.BaseDirectory;
        string python = Path.Combine(root, "runtime", "pythonw.exe");
        bool portable = File.Exists(python);
        if (!portable) python = Path.Combine(root, ".venv", "Scripts", "pythonw.exe");
        string script = Path.Combine(root, "desktop_app.py");
        if (!File.Exists(python) || !File.Exists(script)) {
            MessageBox.Show("缺少 Python 环境或 desktop_app.py。请先按 README 安装 Python 3.12 依赖，提供 runtime\\pythonw.exe 或 .venv\\Scripts\\pythonw.exe，并将 EXE 保留在项目根目录。", "RVC Studio");
            return;
        }
        try {
            var info = new ProcessStartInfo(python, (portable ? "-I " : "") + "\"" + script + "\"");
            info.WorkingDirectory = root;
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            info.WindowStyle = ProcessWindowStyle.Hidden;
            info.EnvironmentVariables["RVC_APP_ROOT"] = root;
            Process.Start(info);
        } catch (Exception error) {
            MessageBox.Show("启动失败：" + error.Message, "RVC Studio");
        }
    }
}
