"""RVC Studio desktop shell. No ML imports on the first-frame path."""
import json
import logging
from logging.handlers import RotatingFileHandler
import math
import os
from pathlib import Path
import subprocess
import sys
import time

BOOT_TIME = time.perf_counter()
from desktop_runtime import DATA, ROOT, load_settings, prepare_environment, save_settings, python_executable
prepare_environment()
_console = open(DATA / 'runtime.log', 'a', encoding='utf-8', buffering=1)
if sys.stdout is None:
    sys.stdout = _console
if sys.stderr is None:
    sys.stderr = _console
logging.basicConfig(level=logging.INFO, handlers=[RotatingFileHandler(
    DATA / 'desktop.log', maxBytes=2_000_000, backupCount=3, encoding='utf-8')],
    format='%(asctime)s %(levelname)s %(name)s: %(message)s')

from PySide6.QtCore import Qt, QTimer, Signal, QCoreApplication, QUrl, QProcess
from PySide6.QtGui import QColor, QFont, QPainter, QLinearGradient, QPen, QDesktopServices, QIcon, QPalette
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QLabel, QPushButton, QVBoxLayout,
    QHBoxLayout, QGridLayout, QComboBox, QLineEdit, QFileDialog, QSlider,
    QCheckBox, QStackedWidget, QScrollArea, QSizePolicy, QMessageBox, QButtonGroup,
)
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from desktop_worker import EngineWorker

STYLE = '''
* {font-family: "Segoe UI", "Microsoft YaHei UI"; font-size:13px; color:#233044;}
QMainWindow {background:#edf1f7;}
QWidget#shell {background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #eef4fa,stop:.6 #f6f5f9,stop:1 #e9eff7);}
QFrame#sidebar {background:rgba(255,255,255,175); border-right:1px solid #dde4ee;}
QFrame#card {background:rgba(255,255,255,215); border:1px solid rgba(255,255,255,245); border-radius:22px;}
QLabel#brand {font-size:23px;font-weight:700;letter-spacing:-1px;}
QLabel#title {font-size:29px;font-weight:700;letter-spacing:-1px;}
QLabel#section {font-size:15px;font-weight:650;}
QLabel#muted {color:#7c8799;font-size:12px;}
QLabel#status {color:#397d6c;background:#e5f3ed;border-radius:12px;padding:7px 12px;}
QLabel#metric {font-size:27px;font-weight:650;color:#28394c;}
QLineEdit,QComboBox {background:#f3f6fa;border:1px solid #e1e7f0;border-radius:10px;padding:9px 11px;min-height:18px;selection-background-color:#1875f0;}
QComboBox::drop-down {border:0;width:26px;}
QComboBox QAbstractItemView {background:white;selection-background-color:#e1edff;selection-color:#17385a;}
QPushButton {background:#eef2f8;border:1px solid #e3e8f0;border-radius:11px;padding:10px 16px;font-weight:600;}
QPushButton:hover {background:#e1ebf9;}
QPushButton:pressed {background:#d1e3fa;}
QPushButton:disabled {color:#9da7b6;background:#eff2f6;border-color:#e8ecf2;}
QPushButton#primary {background:#1479f7;color:white;border:0;border-radius:14px;padding:14px 25px;font-size:15px;}
QPushButton#primary:hover {background:#0867df;}
QPushButton#primary:disabled {background:#b4c9e5;}
QPushButton#nav {text-align:left;background:transparent;border:0;padding:13px 16px;color:#6c788b;}
QPushButton#nav:checked {background:#e3edfc;color:#146be1;}
QPushButton#segment {background:#edf1f6;border:0;padding:9px 16px;}
QPushButton#segment:checked {background:white;color:#126cef;border:1px solid #dae4f3;}
QSlider::groove:horizontal {height:5px;background:#e3e9f1;border-radius:2px;}
QSlider::sub-page:horizontal {background:#2783f4;border-radius:2px;}
QSlider::handle:horizontal {background:white;border:1px solid #cbd7e6;width:18px;margin:-7px 0;border-radius:9px;}
QCheckBox {spacing:9px;padding:5px 0;}
QCheckBox::indicator {width:18px;height:18px;border:1px solid #cad5e4;background:#f5f7fa;border-radius:6px;}
QCheckBox::indicator:checked {background:#227df0;border-color:#227df0;image:none;}
QScrollArea {border:0;background:transparent;}
QScrollBar:vertical {width:7px;background:transparent;}
QScrollBar::handle:vertical {background:#cdd7e5;border-radius:3px;min-height:30px;}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {height:0;}
QToolTip {background:#243044;color:white;border:0;padding:6px;}
'''

def label(text, kind=None):
    item = QLabel(text)
    if kind:
        item.setObjectName(kind)
    return item

def row(*items):
    layout = QHBoxLayout()
    layout.setSpacing(12)
    for item in items:
        if isinstance(item, int):
            layout.addStretch(item)
        else:
            layout.addWidget(item)
    return layout

def card(title=None, subtitle=None):
    frame = QFrame()
    frame.setObjectName('card')
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(22, 19, 22, 20)
    layout.setSpacing(13)
    if title:
        layout.addWidget(label(title, 'section'))
    if subtitle:
        hint = label(subtitle, 'muted')
        hint.setWordWrap(True)
        layout.addWidget(hint)
    return frame, layout

class Meter(QWidget):
    def __init__(self):
        super().__init__()
        self.level = 0.
        self.setMinimumHeight(42)

    def setLevel(self, value):
        self.level = max(float(value), self.level * .72)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        count = 48
        width = max(1., (self.width() - 3*(count-1)) / count)
        db = 20 * math.log10(max(self.level, 1e-5))
        filled = max(0, min(count, int((db + 60) / 60 * count)))
        for i in range(count):
            color = '#dfe7f1'
            if i < filled:
                color = '#42b79b' if i < 35 else '#edb85a' if i < 44 else '#ee7480'
            painter.setBrush(QColor(color))
            painter.setPen(Qt.PenStyle.NoPen)
            height = 11 + (i % 5) * 3
            painter.drawRoundedRect(int(i*(width+3)), int((self.height()-height)/2), int(width), height, 2, 2)

class Slider(QWidget):
    changed = Signal(float)
    def __init__(self, title, minimum, maximum, step, value, suffix=''):
        super().__init__()
        self.minimum, self.step = minimum, step
        self.suffix = suffix
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 3, 0, 3)
        layout.setSpacing(7)
        self.number = label('')
        self.number.setStyleSheet('color:#1975ec;font-weight:600;')
        layout.addLayout(row(label(title), 1, self.number))
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, round((maximum-minimum)/step))
        self.slider.setValue(round((value-minimum)/step))
        self.slider.setAccessibleName(title)
        self.slider.valueChanged.connect(self._changed)
        layout.addWidget(self.slider)
        self._changed(self.slider.value())

    def _changed(self, position):
        value = round(self.minimum + position * self.step, 4)
        self.number.setText(f'{value:g}{self.suffix}')
        self.changed.emit(value)

    def value(self):
        return round(self.minimum+self.slider.value()*self.step, 4)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = load_settings()
        self.records = []
        self.busy = True
        self.running = False
        self.closing = False
        self.studio = None
        self.webview = None
        self.studio_ready = False
        self.studio_started = 0
        self.controls = {}
        self.restart_controls = []
        self.setWindowTitle('RVC Studio · 实时变声工作室')
        self.resize(1150, 830)
        self.setMinimumSize(960, 720)
        icon = ROOT / 'rvc-studio.ico'
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        shell = QWidget()
        shell.setObjectName('shell')
        self.setCentralWidget(shell)
        outer = QHBoxLayout(shell)
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(0)
        sidebar = QFrame()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(196)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(19,28,19,20)
        side.addWidget(label('◉  RVC', 'brand'))
        side.addWidget(label('VOICE STUDIO', 'muted'))
        side.addSpacing(34)
        self.nav = QButtonGroup(self)
        for i, title in enumerate(('◌   实时变声','☷   音频工作室','⚙   高级设置')):
            button = QPushButton(title)
            button.setObjectName('nav')
            button.setCheckable(True)
            self.nav.addButton(button, i)
            side.addWidget(button)
            if i == 0:
                button.setChecked(True)
        self.nav.idClicked.connect(self.navigate)
        side.addStretch()
        self.gpu_label = label('引擎准备中…', 'muted')
        self.gpu_label.setWordWrap(True)
        side.addWidget(self.gpu_label)
        side.addWidget(label('RVC Studio  1.0', 'muted'))
        outer.addWidget(sidebar)
        main = QVBoxLayout()
        main.setContentsMargins(28,26,28,21)
        main.setSpacing(18)
        self.title = label('让声音，成为你。', 'title')
        self.status = label('正在准备', 'status')
        main.addLayout(row(self.title, 1, self.status))
        self.subtitle = label('实时变声 · 清晰路由 · 即时掌控', 'muted')
        main.addWidget(self.subtitle)
        self.pages = QStackedWidget()
        self.pages.addWidget(self.realtime_page())
        self.pages.addWidget(self.studio_page())
        self.pages.addWidget(self.advanced_page())
        main.addWidget(self.pages, 1)
        self.message = label('正在后台加载引擎，界面已经就绪。', 'muted')
        self.message.setWordWrap(True)
        main.addWidget(self.message)
        outer.addLayout(main, 1)
        self.worker = EngineWorker(self.settings, self)
        self.worker.ready.connect(self.devices_ready)
        self.worker.state.connect(self.engine_state)
        self.worker.failed.connect(self.engine_error)
        self.timer = QTimer(self)
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.poll)
        self.timer.start()
        QTimer.singleShot(0, self.first_frame)
        QTimer.singleShot(80, self.worker.start)

    def first_frame(self):
        elapsed = time.perf_counter() - BOOT_TIME
        logging.info('UI first frame %.3f seconds', elapsed)
        (DATA / 'startup.json').write_text(json.dumps(dict(ui_seconds=elapsed)), encoding='utf-8')
        if os.environ.get('RVC_DESKTOP_CAPTURE'):
            QTimer.singleShot(1200, lambda: self.grab().save(os.environ['RVC_DESKTOP_CAPTURE']))

    def scroll(self, widget):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(widget)
        return scroll

    def realtime_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(16)
        model, body = card('声音模型', '加载本地声音模型，保留原有模型与索引格式。')
        for key, title, suffix in [('pth_path','声音模型','.pth'),('index_path','检索索引','.index')]:
            field = QLineEdit(self.settings[key])
            field.setPlaceholderText(f'选择 {suffix} 文件')
            field.setAccessibleName(title)
            self.controls[key] = field
            button = QPushButton('选择文件')
            button.clicked.connect(lambda checked=False,k=key,s=suffix: self.choose(k,s))
            body.addLayout(row(field,button))
            self.restart_controls.extend([field,button])
        layout.addWidget(model)
        devices, body = card('音频路由')
        grid = QGridLayout()
        grid.setHorizontalSpacing(16)
        grid.setVerticalSpacing(8)
        for col, (key, title) in enumerate([('sg_input_device','输入 · 麦克风'),('sg_output_device','输出 · 虚拟声卡 / 耳机')]):
            combo = QComboBox()
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            combo.setMinimumContentsLength(12)
            combo.setAccessibleName(title)
            self.controls[key] = combo
            self.restart_controls.append(combo)
            grid.addWidget(label(title,'muted'),0,col)
            grid.addWidget(combo,1,col)
        body.addLayout(grid)
        input_meter, output_meter = Meter(), Meter()
        self.input_meter, self.output_meter = input_meter, output_meter
        body.addLayout(row(input_meter,output_meter))
        self.route_hint = label('设备列表正在准备…','muted')
        self.route_hint.setWordWrap(True)
        body.addWidget(self.route_hint)
        layout.addWidget(devices)
        tuning, body = card('声音塑形')
        grid = QGridLayout()
        grid.setHorizontalSpacing(28)
        for i, spec in enumerate([
            ('pitch','音调',-24,24,1,' 半音'),('formant','声线粗细',-2,2,.05,''),
            ('rms_mix_rate','响度混合',0,1,.01,''),('index_rate','索引检索',0,1,.01,'')]):
            key,title,low,high,step,suffix = spec
            slider = Slider(title,low,high,step,self.settings[key],suffix)
            self.controls[key] = slider
            slider.changed.connect(lambda value,k=key:self.changed(k,value))
            grid.addWidget(slider,i//2,i%2)
            if key == 'index_rate':
                self.restart_controls.append(slider)
        body.addLayout(grid)
        self.mode = QButtonGroup(self)
        self.mode.setExclusive(True)
        line = QHBoxLayout()
        for i,(value,title) in enumerate([('vc','输出变声'),('im','输入监听')]):
            button = QPushButton(title)
            button.setObjectName('segment')
            button.setCheckable(True)
            button.setChecked(self.settings['function']==value)
            self.mode.addButton(button,i)
            button.clicked.connect(lambda checked=False,v=value:self.changed('function',v))
            line.addWidget(button)
        line.addStretch()
        body.addLayout(line)
        layout.addWidget(tuning)
        footer, body = card()
        self.start_button = QPushButton('开始变声')
        self.start_button.setObjectName('primary')
        self.start_button.setEnabled(False)
        self.start_button.clicked.connect(self.toggle)
        self.refresh_button = QPushButton('刷新设备')
        self.refresh_button.clicked.connect(self.refresh)
        self.refresh_button.setEnabled(False)
        self.infer_label, self.delay_label = label('—','metric'), label('—','metric')
        infer, delay = QVBoxLayout(), QVBoxLayout()
        infer.addWidget(self.infer_label)
        infer.addWidget(label('推理耗时 ms','muted'))
        delay.addWidget(self.delay_label)
        delay.addWidget(label('预计总延迟 ms','muted'))
        line = row(self.start_button,self.refresh_button,1)
        line.addLayout(infer)
        line.addSpacing(22)
        line.addLayout(delay)
        body.addLayout(line)
        layout.addWidget(footer)
        layout.removeWidget(footer)
        container=QWidget()
        fixed=QVBoxLayout(container)
        fixed.setContentsMargins(0,0,0,0)
        fixed.setSpacing(12)
        fixed.addWidget(self.scroll(page),1)
        fixed.addWidget(footer)
        return container

    def advanced_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0,0,0,0)
        layout.setSpacing(16)
        audio, body = card('音频设备与采样率','更换设备类型或采样率前，请先停止转换。')
        for key,title,choices in [('sg_hostapi','设备类型',[]),('sr_type','采样率来源',[('设备采样率','sr_device'),('模型采样率','sr_model')]),('f0method','音高算法',[('RMVPE','rmvpe'),('FCPE','fcpe'),('Praat / PM','pm')])]:
            combo = QComboBox()
            combo.setAccessibleName(title)
            for text,value in choices:
                combo.addItem(text,value)
            index = combo.findData(self.settings[key])
            if index>=0:
                combo.setCurrentIndex(index)
            self.controls[key] = combo
            body.addLayout(row(label(title),1,combo))
            if key=='sg_hostapi':
                combo.currentTextChanged.connect(self.populate_devices)
                self.restart_controls.append(combo)
            elif key=='sr_type':
                self.restart_controls.append(combo)
            else:
                combo.currentIndexChanged.connect(lambda i,c=combo:self.changed('f0method',c.currentData()))
        for key,title in [('sg_wasapi_exclusive','独占 WASAPI 设备'),('I_noise_reduce','输入降噪'),('O_noise_reduce','输出降噪')]:
            check=QCheckBox(title)
            check.setChecked(bool(self.settings[key]))
            self.controls[key]=check
            body.addWidget(check)
            if key=='sg_wasapi_exclusive':
                self.restart_controls.append(check)
            else:
                check.toggled.connect(lambda value,k=key:self.changed(k,value))
        layout.addWidget(audio)
        performance,body=card('性能与延迟','更小的采样块降低延迟，但会增加实时处理压力。')
        for key,title,lo,hi,step,suffix in [('block_time','采样块长度',.03,1.5,.01,' s'),('crossfade_length','交叉淡化长度',.01,.5,.01,' s'),('extra_time','额外推理时长',.05,5,.05,' s'),('threhold','静音阈值',-60,0,1,' dB')]:
            slider=Slider(title,lo,hi,step,self.settings[key],suffix)
            self.controls[key]=slider
            body.addWidget(slider)
            slider.changed.connect(lambda value,k=key:self.changed(k,value))
            if key!='threhold':
                self.restart_controls.append(slider)
        graph=QCheckBox('CUDA Graph 加速 · 重启软件后生效')
        graph.setChecked(self.settings['cuda_graph'])
        self.controls['cuda_graph']=graph
        graph.toggled.connect(lambda v:self.settings.update(cuda_graph=v))
        body.addWidget(graph)
        layout.addWidget(performance)
        helpcard,body=card('诊断与恢复')
        logs=QPushButton('打开诊断日志')
        logs.clicked.connect(lambda:QDesktopServices.openUrl(QUrl.fromLocalFile(str(DATA))))
        body.addWidget(logs)
        self.health=label('没有音频流错误。','muted')
        self.health.setWordWrap(True)
        body.addWidget(self.health)
        layout.addWidget(helpcard)
        layout.addStretch()
        return self.scroll(page)

    def studio_page(self):
        page=QWidget()
        self.studio_layout=QVBoxLayout(page)
        self.studio_layout.setContentsMargins(0,0,0,0)
        self.studio_intro=label('音频转换、人声分离、模型训练、索引与模型工具\n\n首次打开时按需加载，实时变声启动不会等待这些功能。','muted')
        self.studio_intro.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.studio_layout.addWidget(self.studio_intro,1)
        self.studio_button=QPushButton('打开完整音频工作室')
        self.studio_button.setObjectName('primary')
        self.studio_button.clicked.connect(self.open_studio)
        self.studio_layout.addWidget(self.studio_button)
        return page

    def navigate(self,index):
        self.pages.setCurrentIndex(index)
        self.title.setText(['让声音，成为你。','音频工作室','按你的方式调校。'][index])
        self.subtitle.setText(['实时变声 · 清晰路由 · 即时掌控','离线转换 / 人声分离 / 训练 / 模型工具','音频设备、算法与实时性能'][index])

    def choose(self,key,suffix):
        path,_=QFileDialog.getOpenFileName(self,'选择声音模型' if key=='pth_path' else '选择索引',str(ROOT/'assets' if key=='pth_path' else ROOT/'logs'),f'模型文件 (*{suffix})')
        if path:
            self.controls[key].setText(path)

    def values(self):
        values=self.settings.copy()
        for key,widget in self.controls.items():
            if isinstance(widget,QLineEdit):
                values[key]=widget.text().strip()
            elif isinstance(widget,QComboBox):
                values[key]=widget.currentData() if widget.currentData() is not None else widget.currentText()
            elif isinstance(widget,QCheckBox):
                values[key]=widget.isChecked()
            elif isinstance(widget,Slider):
                values[key]=widget.value()
        return values

    def devices_ready(self,records):
        self.records=records
        combo=self.controls['sg_hostapi']
        previous=combo.currentText() or self.settings['sg_hostapi']
        combo.blockSignals(True)
        combo.clear()
        combo.addItems(list(dict.fromkeys(d['hostapi'] for d in records)))
        combo.setCurrentText(previous)
        combo.blockSignals(False)
        self.populate_devices()

    def populate_devices(self,*args):
        api=self.controls['sg_hostapi'].currentText()
        for key,direction in [('sg_input_device','inputs'),('sg_output_device','outputs')]:
            combo=self.controls[key]
            old=combo.currentText() or self.settings[key]
            combo.clear()
            for d in self.records:
                if d['hostapi']==api and d[direction]>0:
                    combo.addItem(d['name'])
                    combo.setItemData(combo.count()-1,f"设备 #{d['id']} · {d['rate']} Hz",Qt.ItemDataRole.ToolTipRole)
            found=combo.findText(old)
            combo.setCurrentIndex(found if found>=0 else -1)
            combo.setPlaceholderText('请选择设备' if combo.count() else '未发现可用设备')
        self.route_hint.setText('麦克风 → RVC → 所选输出；虚拟声卡需在 Voicemeeter 中开启监听。')

    def refresh(self):
        self.busy=True
        self.refresh_button.setEnabled(False)
        self.start_button.setEnabled(False)
        self.message.setText('正在重新枚举音频设备…')
        self.worker.submit('refresh')

    def changed(self,key,value):
        self.settings[key]=value
        hot={'pitch','formant','rms_mix_rate','threhold','I_noise_reduce','O_noise_reduce','function','f0method'}
        if hasattr(self,'worker') and self.worker.engine and key in hot:
            self.worker.submit('change',(key,value))

    def toggle(self):
        if self.busy:
            return
        if self.running:
            self.busy=True
            self.start_button.setEnabled(False)
            self.worker.submit('stop')
            return
        self.settings=self.values()
        if not self.settings['sg_input_device'] or not self.settings['sg_output_device']:
            self.engine_error('请明确选择输入和输出设备，防止声音送到错误设备。')
            return
        try:
            save_settings(self.settings)
        except OSError as error:
            self.engine_error(str(error))
            return
        self.busy=True
        self.lock_controls(True)
        self.start_button.setEnabled(False)
        self.worker.submit('start',self.settings.copy())

    def lock_controls(self,locked):
        for widget in self.restart_controls:
            widget.setEnabled(not locked)
        self.refresh_button.setEnabled(not locked and self.worker.engine is not None)

    def engine_state(self,state,payload):
        if state in ('loading','starting'):
            self.status.setText('正在加载' if state=='loading' else '正在预热')
            self.message.setText(str(payload))
            return
        self.busy=False
        self.running=state=='running'
        if state=='ready':
            self.gpu_label.setText('音频引擎已就绪\n'+payload['device'])
            self.message.setText(f"引擎准备完成，用时 {payload['seconds']:.1f} 秒。选择模型后即可开始。")
            logging.info('Engine ready %.3fs',payload['seconds'])
        elif state=='running':
            self.message.setText(f"正在输出至 {self.settings['sg_output_device']} · {payload['rate']} Hz")
        else:
            self.message.setText('转换已停止，模型保留在内存中，便于快速再次启动。')
        self.status.setText('实时运行' if self.running else '准备就绪')
        self.start_button.setText('停止变声' if self.running else '开始变声')
        self.start_button.setEnabled(True)
        self.lock_controls(self.running)

    def engine_error(self,message):
        self.busy=False
        self.running=bool(self.worker.engine and self.worker.engine.running)
        self.status.setText('需要处理')
        self.message.setText(message)
        self.message.setStyleSheet('color:#c45763;')
        self.health.setText(message)
        self.start_button.setText('停止变声' if self.running else '重试启动')
        self.start_button.setEnabled(self.worker.engine is not None)
        self.lock_controls(self.running)

    def poll(self):
        engine=self.worker.engine
        if engine:
            stats=engine.stats.copy()
            self.input_meter.setLevel(stats['input'] if engine.running else 0)
            self.output_meter.setLevel(stats['output'] if engine.running else 0)
            self.infer_label.setText(f"{stats['infer_ms']:.0f}" if stats['sequence'] else '—')
            self.delay_label.setText(f"{stats['delay_ms']:.0f}" if stats['rate'] else '—')
            self.health.setText(f"音频状态异常次数：{stats['overruns']} · 输入峰值 {stats['input']:.3f} · 输出峰值 {stats['output']:.3f}")
            if stats['error'] and self.running:
                self.worker.submit('stop')
                self.engine_error(stats['error'])
        if self.studio and not self.studio_ready:
            self.check_studio()

    def open_studio(self):
        if self.studio:
            return
        # Keep the engine and Qt view on the main thread; server runs separately.
        import socket
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0))
            self.studio_port=sock.getsockname()[1]
        self.studio=QProcess(self)
        self.studio.setWorkingDirectory(str(ROOT))
        self.studio.setProgram(str(python_executable(windowed=True)))
        self.studio.setArguments(['-I',str(ROOT/'studio_server.py'),str(self.studio_port)])
        self.studio.setStandardOutputFile(str(DATA/'studio-bootstrap.log'))
        self.studio.setStandardErrorFile(str(DATA/'studio-bootstrap.log'))
        self.studio.start()
        self.studio_started=time.monotonic()
        self.studio_intro.setText('正在启动完整音频工作室…\n实时变声仍可使用。')
        self.studio_button.setEnabled(False)
        self.studio_button.setText('工作室加载中…')

    def check_studio(self):
        # Socket probe is non-blocking; no synchronous HTTP request on the UI.
        import socket
        sock=socket.socket()
        sock.settimeout(.002)
        try:
            connected=sock.connect_ex(('127.0.0.1',self.studio_port))==0
        finally:
            sock.close()
        if connected:
            self.embed_studio()
        elif self.studio.state()==QProcess.ProcessState.NotRunning or time.monotonic()-self.studio_started>180:
            self.studio_intro.setText('工作室启动失败。请打开高级设置中的诊断日志，查看 studio.log。')
            self.studio.kill()
            self.studio=None
            self.studio_button.setEnabled(True)
            self.studio_button.setText('重新启动工作室')

    def embed_studio(self):
        self.studio_ready=True
        try:
            from PySide6.QtWebEngineWidgets import QWebEngineView
            from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile
            port=self.studio_port
            class LocalPage(QWebEnginePage):
                def acceptNavigationRequest(self,url,kind,main):
                    if not main:
                        return True
                    if url.scheme() in ('http','https') and url.host()=='127.0.0.1' and url.port()==port:
                        return True
                    if url.scheme()=='about':
                        return True
                    if url.scheme() in ('http','https'):
                        QDesktopServices.openUrl(url)
                    return False
            self.webview=QWebEngineView()
            self.webprofile=QWebEngineProfile('rvc-studio',self.webview)
            self.webprofile.setCachePath(str(DATA/'web-cache'))
            self.webprofile.setPersistentStoragePath(str(DATA/'web-storage'))
            self.webprofile.downloadRequested.connect(self.download)
            self.webview.setPage(LocalPage(self.webprofile,self.webview))
            self.studio_intro.hide()
            self.studio_button.hide()
            self.studio_layout.addWidget(self.webview,1)
            self.webview.load(QUrl(f'http://127.0.0.1:{port}/'))
        except Exception as error:
            logging.exception('Studio embed failed')
            self.studio_intro.setText(f'内嵌界面加载失败：{error}')

    def download(self,item):
        path,_=QFileDialog.getSaveFileName(self,'保存工作室文件',item.downloadFileName())
        if path:
            item.setDownloadDirectory(str(Path(path).parent))
            item.setDownloadFileName(Path(path).name)
            item.accept()

    def closeEvent(self,event):
        if self.closing:
            event.ignore()
            return
        if self.worker.isRunning():
            self.closing=True
            self.status.setText('正在退出')
            self.message.setText('正在释放音频设备与后台任务…')
            self.setEnabled(False)
            self.worker.submit('quit')
            self.worker.finished.connect(self.finish_close)
            event.ignore()
            return
        self.cleanup()
        event.accept()

    def finish_close(self):
        self.closing=False
        self.cleanup()
        self.close()

    def cleanup(self):
        try:
            save_settings(self.values())
        except OSError:
            logging.exception('Settings save failed')
        if self.studio:
            # Only the server process tree created by this window is terminated.
            pid=self.studio.processId()
            if pid:
                subprocess.run(['taskkill','/PID',str(pid),'/T','/F'],
                    creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            self.studio=None

def main():
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    app=QApplication(sys.argv[:1])
    app.setApplicationName('RVC Studio')
    app.setOrganizationName('RVC')
    app.setStyle('Fusion')
    palette=QPalette()
    for role,color in [(QPalette.ColorRole.Window,'#eff3f9'),(QPalette.ColorRole.Base,'#ffffff'),
                       (QPalette.ColorRole.WindowText,'#233044'),(QPalette.ColorRole.Text,'#233044'),
                       (QPalette.ColorRole.Button,'#edf2f8'),(QPalette.ColorRole.ButtonText,'#233044'),
                       (QPalette.ColorRole.Highlight,'#227df0'),(QPalette.ColorRole.HighlightedText,'#ffffff')]:
        palette.setColor(role,QColor(color))
    app.setPalette(palette)
    app.setStyleSheet(STYLE)
    # A second click activates the existing window instead of opening another stream.
    probe=QLocalSocket()
    probe.connectToServer('RVCStudio.Desktop')
    if probe.waitForConnected(150):
        probe.write(b'show')
        probe.flush()
        probe.waitForBytesWritten(150)
        return 0
    server=QLocalServer()
    QLocalServer.removeServer('RVCStudio.Desktop')
    server.listen('RVCStudio.Desktop')
    window=MainWindow()
    def activate():
        client=server.nextPendingConnection()
        if client:
            client.deleteLater()
        window.showNormal()
        window.raise_()
        window.activateWindow()
    server.newConnection.connect(activate)
    window.show()
    return app.exec()

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception:
        logging.exception('Desktop startup failed')
        raise
