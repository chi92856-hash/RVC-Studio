"""DSP extracted from realtime_gui.py. Imported only by the engine worker.

RVC inference, pitch extraction, SOLA, denoising and resampling remain intact.
"""
import os
import sys
import time
import traceback
import logging
import numpy as np
import librosa
import torch
import torch.nn.functional as F
import torchaudio.transforms as tat
from tools.torchgate import TorchGate
from configs.config import Config
from infer import rtrvc as rvc_for_realtime
from tools.cuda_graph import cuda_graph_enabled, run_cuda_graph
from i18n.i18n import I18nAuto
i18n = I18nAuto()
def printt(message, *args):
    logging.getLogger('rvc.engine').debug(message, *args)

class DSPCore:

    def start_vc(self):
        self.rvc = rvc_for_realtime.RVC(self.gui_config.pitch, self.gui_config.formant, self.gui_config.pth_path, self.gui_config.index_path, self.gui_config.index_rate, self.config, self.rvc if hasattr(self, 'rvc') else None)
        self.gui_config.samplerate = self.rvc.tgt_sr if self.gui_config.sr_type == 'sr_model' else self.get_device_samplerate()
        self.gui_config.channels = self.get_device_channels()
        self.zc = self.gui_config.samplerate // 100
        self.block_frame = int(np.round(self.gui_config.block_time * self.gui_config.samplerate / self.zc)) * self.zc
        self.block_frame_16k = 160 * self.block_frame // self.zc
        self.crossfade_frame = int(np.round(self.gui_config.crossfade_time * self.gui_config.samplerate / self.zc)) * self.zc
        self.sola_buffer_frame = min(self.crossfade_frame, 4 * self.zc)
        self.sola_search_frame = self.zc
        self.extra_frame = int(np.round(self.gui_config.extra_time * self.gui_config.samplerate / self.zc)) * self.zc
        self.input_wav = torch.zeros(self.extra_frame + self.crossfade_frame + self.sola_search_frame + self.block_frame, device=self.config.device, dtype=torch.float32)
        self.input_wav_denoise = self.input_wav.clone()
        self.input_wav_res = torch.zeros(160 * self.input_wav.shape[0] // self.zc, device=self.config.device, dtype=torch.float32)
        self.rms_buffer = np.zeros(4 * self.zc, dtype='float32')
        self.sola_buffer = torch.zeros(self.sola_buffer_frame, device=self.config.device, dtype=torch.float32)
        self.sola_den_kernel = torch.ones(1, 1, self.sola_buffer_frame, device=self.config.device, dtype=torch.float32)
        self.nr_buffer = self.sola_buffer.clone()
        self.output_buffer = self.input_wav.clone()
        self.skip_head = self.extra_frame // self.zc
        self.return_length = (self.block_frame + self.sola_buffer_frame + self.sola_search_frame) // self.zc
        self.fade_in_window = torch.sin(0.5 * np.pi * torch.linspace(0.0, 1.0, steps=self.sola_buffer_frame, device=self.config.device, dtype=torch.float32)) ** 2
        self.fade_out_window = 1 - self.fade_in_window
        self.resampler = tat.Resample(orig_freq=self.gui_config.samplerate, new_freq=16000, dtype=torch.float32).to(self.config.device)
        if self.rvc.tgt_sr != self.gui_config.samplerate:
            self.resampler2 = tat.Resample(orig_freq=self.rvc.tgt_sr, new_freq=self.gui_config.samplerate, dtype=torch.float32).to(self.config.device)
        else:
            self.resampler2 = None
        self.tg = TorchGate(sr=self.gui_config.samplerate, n_fft=4 * self.zc, prop_decrease=0.9).to(self.config.device)
        self.prewarm_cuda_graph()
        self.start_stream()

    def prewarm_cuda_graph(self):
        if not cuda_graph_enabled(self.config.device):
            return
        try:
            printt(i18n('正在预热CUDA Graph'))
            samples = self.input_wav_res.shape[0]
            phase = torch.arange(samples, device=self.config.device, dtype=torch.float32)
            probe = 0.05 * torch.sin(2 * np.pi * 220.0 * phase / 16000.0)
            self.input_wav_res.copy_(probe)
            if self.gui_config.I_noise_reduce:
                short = self.input_wav[-self.sola_buffer_frame - self.block_frame:].unsqueeze(0)
                self.tg(short, self.input_wav.unsqueeze(0))
            resample_input = self.input_wav[-self.block_frame - 2 * self.zc:]
            run_cuda_graph(self.resampler, 'realtime-input-resample', lambda audio: self.resampler(audio), resample_input)
            inferred = self.rvc.infer(self.input_wav_res, self.block_frame_16k, self.skip_head, self.return_length, self.gui_config.f0method)
            if self.resampler2 is not None:
                inferred = run_cuda_graph(self.resampler2, 'realtime-output-resample', lambda audio: self.resampler2(audio), inferred)
            if self.gui_config.O_noise_reduce:
                self.tg(inferred.unsqueeze(0), self.output_buffer.unsqueeze(0))
            torch.cuda.synchronize(self.config.device)
            printt(i18n('CUDA Graph预热完成'))
        except Exception:
            printt(traceback.format_exc())
        finally:
            self.input_wav.zero_()
            self.input_wav_denoise.zero_()
            self.input_wav_res.zero_()
            self.output_buffer.zero_()
            self.sola_buffer.zero_()
            self.nr_buffer.zero_()
            self.rvc.cache_pitch.zero_()
            self.rvc.cache_pitchf.zero_()

    @torch.inference_mode()
    def _process_audio(self, indata, outdata, frames, times, status):
        """
            音频处理
            """
        start_time = time.perf_counter()
        indata = indata.mean(axis=1, dtype=np.float32)
        if self.gui_config.threhold > -60:
            indata = np.append(self.rms_buffer, indata)
            rms = librosa.feature.rms(y=indata, frame_length=4 * self.zc, hop_length=self.zc)[:, 2:]
            self.rms_buffer[:] = indata[-4 * self.zc:]
            indata = indata[2 * self.zc - self.zc // 2:]
            db_threhold = librosa.amplitude_to_db(rms, ref=1.0)[0] < self.gui_config.threhold
            for i in range(db_threhold.shape[0]):
                if db_threhold[i]:
                    indata[i * self.zc:(i + 1) * self.zc] = 0
            indata = indata[self.zc // 2:]
        self.input_wav[:-self.block_frame] = self.input_wav[self.block_frame:].clone()
        self.input_wav[-indata.shape[0]:] = torch.from_numpy(indata).to(self.config.device)
        self.input_wav_res[:-self.block_frame_16k] = self.input_wav_res[self.block_frame_16k:].clone()
        if self.gui_config.I_noise_reduce:
            self.input_wav_denoise[:-self.block_frame] = self.input_wav_denoise[self.block_frame:].clone()
            input_wav = self.input_wav[-self.sola_buffer_frame - self.block_frame:]
            input_wav = self.tg(input_wav.unsqueeze(0), self.input_wav.unsqueeze(0)).squeeze(0)
            input_wav[:self.sola_buffer_frame] *= self.fade_in_window
            input_wav[:self.sola_buffer_frame] += self.nr_buffer * self.fade_out_window
            self.input_wav_denoise[-self.block_frame:] = input_wav[:self.block_frame]
            self.nr_buffer[:] = input_wav[self.block_frame:]
            resample_input = self.input_wav_denoise[-self.block_frame - 2 * self.zc:]
            self.input_wav_res[-self.block_frame_16k - 160:] = run_cuda_graph(self.resampler, 'realtime-input-resample', lambda audio: self.resampler(audio), resample_input)[160:]
        else:
            resample_input = self.input_wav[-indata.shape[0] - 2 * self.zc:]
            self.input_wav_res[-160 * (indata.shape[0] // self.zc + 1):] = run_cuda_graph(self.resampler, 'realtime-input-resample', lambda audio: self.resampler(audio), resample_input)[160:]
        if self.function == 'vc':
            infer_wav = self.rvc.infer(self.input_wav_res, self.block_frame_16k, self.skip_head, self.return_length, self.gui_config.f0method)
            if self.resampler2 is not None:
                infer_wav = run_cuda_graph(self.resampler2, 'realtime-output-resample', lambda audio: self.resampler2(audio), infer_wav)
        elif self.gui_config.I_noise_reduce:
            infer_wav = self.input_wav_denoise[self.extra_frame:].clone()
        else:
            infer_wav = self.input_wav[self.extra_frame:].clone()
        if self.gui_config.O_noise_reduce and self.function == 'vc':
            self.output_buffer[:-self.block_frame] = self.output_buffer[self.block_frame:].clone()
            self.output_buffer[-self.block_frame:] = infer_wav[-self.block_frame:]
            infer_wav = self.tg(infer_wav.unsqueeze(0), self.output_buffer.unsqueeze(0)).squeeze(0)
        if self.gui_config.rms_mix_rate < 1 and self.function == 'vc':
            if self.gui_config.I_noise_reduce:
                input_wav = self.input_wav_denoise[self.extra_frame:]
            else:
                input_wav = self.input_wav[self.extra_frame:]
            rms1 = librosa.feature.rms(y=input_wav[:infer_wav.shape[0]].cpu().numpy(), frame_length=4 * self.zc, hop_length=self.zc)
            rms1 = torch.from_numpy(rms1).to(self.config.device)
            rms1 = F.interpolate(rms1.unsqueeze(0), size=infer_wav.shape[0] + 1, mode='linear', align_corners=True)[0, 0, :-1]
            rms2 = librosa.feature.rms(y=infer_wav[:].cpu().numpy(), frame_length=4 * self.zc, hop_length=self.zc)
            rms2 = torch.from_numpy(rms2).to(self.config.device)
            rms2 = F.interpolate(rms2.unsqueeze(0), size=infer_wav.shape[0] + 1, mode='linear', align_corners=True)[0, 0, :-1]
            rms2 = torch.max(rms2, torch.zeros_like(rms2) + 0.001)
            infer_wav *= torch.pow(rms1 / rms2, 1.0 - self.gui_config.rms_mix_rate)
        conv_input = infer_wav[None, None, :self.sola_buffer_frame + self.sola_search_frame]
        cor_nom = F.conv1d(conv_input, self.sola_buffer[None, None, :])
        cor_den = torch.sqrt(F.conv1d(conv_input ** 2, self.sola_den_kernel) + 1e-08)
        if sys.platform == 'darwin':
            _, sola_offset = torch.max(cor_nom[0, 0] / cor_den[0, 0])
            sola_offset = sola_offset.item()
        else:
            sola_offset = torch.argmax(cor_nom[0, 0] / cor_den[0, 0])
        infer_wav = infer_wav[sola_offset:]
        infer_wav[:self.sola_buffer_frame] *= self.fade_in_window
        infer_wav[:self.sola_buffer_frame] += self.sola_buffer * self.fade_out_window
        self.sola_buffer[:] = infer_wav[self.block_frame:self.block_frame + self.sola_buffer_frame]
        outdata[:] = infer_wav[:self.block_frame].cpu().numpy()[:, None]
        total_time = time.perf_counter() - start_time
