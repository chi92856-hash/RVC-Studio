"""Serialized engine worker; the audio callback never touches Qt widgets."""
import logging
import time
from types import SimpleNamespace

import numpy as np
import sounddevice as sd
import torch

from desktop_dsp import DSPCore
from desktop_runtime import device_records, resolve_device, validate_settings
from configs.config import Config

log = logging.getLogger(__name__)

class Engine(DSPCore):
    def __init__(self):
        self.config = Config()
        self.stream = None
        self.running = False
        self.records = []
        self.stats = dict(input=0., output=0., infer_ms=0., delay_ms=0.,
                          rate=0, overruns=0, error='', sequence=0)
        self.refresh()

    def refresh(self):
        if self.stream is not None:
            raise RuntimeError('请先停止转换，再刷新设备。')
        # Reinitialize only while stopped so hot-plugged endpoints are visible.
        sd._terminate()
        sd._initialize()
        self.records = device_records(sd.query_devices(), sd.query_hostapis())
        return self.records

    def start(self, settings):
        self.stop_stream()
        values = validate_settings(settings)
        self.input_device = resolve_device(self.records, values['sg_input_device'], values['sg_hostapi'], 'inputs')
        self.output_device = resolve_device(self.records, values['sg_output_device'], values['sg_hostapi'], 'outputs')
        self.gui_config = SimpleNamespace(**values)
        self.gui_config.crossfade_time = values['crossfade_length']
        self.function = values['function']
        self.stats = dict(input=0., output=0., infer_ms=0., delay_ms=0.,
                          rate=0, overruns=0, error='', sequence=0)
        # Existing model/Hubert/pitch models stay resident across stop/start.
        self.start_vc()
        if not hasattr(self.rvc, 'net_g') or self.rvc.net_g is None:
            raise RuntimeError('模型加载失败，请查看诊断日志。')
        latency = self.stream.latency[-1]
        self.stats['delay_ms'] = 1000 * (latency + values['block_time'] + values['crossfade_length'] + .01
            + (min(values['crossfade_length'], .04) if values['I_noise_reduce'] else 0))
        self.stats['rate'] = self.gui_config.samplerate
        return dict(self.stats)

    def get_device_samplerate(self):
        # Match the receiving endpoint (Voicemeeter), then verify both endpoints.
        rate = self.output_device['rate']
        self._check_format(rate)
        return rate

    def get_device_channels(self):
        return min(self.output_device['outputs'], 2)

    def _check_format(self, rate):
        sd.check_input_settings(device=self.input_device['id'],
                                channels=min(self.input_device['inputs'], 2),
                                dtype='float32', samplerate=rate)
        sd.check_output_settings(device=self.output_device['id'],
                                 channels=min(self.output_device['outputs'], 2),
                                 dtype='float32', samplerate=rate)

    def start_stream(self):
        if not hasattr(self.rvc, 'net_g') or self.rvc.net_g is None:
            raise RuntimeError('声音模型未成功加载')
        self._check_format(self.gui_config.samplerate)
        extra = sd.WasapiSettings(exclusive=True) if (
            'WASAPI' in self.gui_config.sg_hostapi and self.gui_config.sg_wasapi_exclusive) else None
        try:
            self.stream = sd.Stream(
                device=(self.input_device['id'], self.output_device['id']),
                channels=(min(self.input_device['inputs'], 2), self.gui_config.channels),
                samplerate=self.gui_config.samplerate, blocksize=self.block_frame,
                dtype='float32', callback=self.audio_callback, extra_settings=extra)
            self.running = True
            self.stream.start()
        except Exception:
            self.stop_stream()
            raise

    def stop_stream(self):
        self.running = False
        stream, self.stream = self.stream, None
        if stream is not None:
            try:
                stream.abort()
            finally:
                stream.close()

    def audio_callback(self, indata, outdata, frames, times, status):
        if not self.running:
            outdata.fill(0)
            return
        try:
            if status:
                self.stats['overruns'] += 1
            self._process_audio(indata, outdata, frames, times, status)
            self.stats['input'] = float(np.max(np.abs(indata)))
            self.stats['output'] = float(np.max(np.abs(outdata)))
            self.stats['sequence'] += 1
        except Exception as error:
            outdata.fill(0)
            self.running = False
            self.stats['error'] = str(error)
            log.exception('Audio callback stopped')
            raise sd.CallbackAbort from error

    def change(self, key, value):
        if not hasattr(self, 'gui_config'):
            return
        if key == 'function':
            self.function = value
        else:
            setattr(self.gui_config, key, value)
        if hasattr(self, 'rvc'):
            if key == 'pitch':
                self.rvc.change_key(value)
            elif key == 'formant':
                self.rvc.change_formant(value)
            elif key == 'index_rate':
                # Loading an index while the audio callback reads it is unsafe.
                if self.running:
                    raise RuntimeError('修改索引比例前请停止转换')
                self.rvc.change_index_rate(value)
        if key == 'I_noise_reduce':
            latency = self.stream.latency[-1] if self.stream else 0
            c = self.gui_config
            self.stats['delay_ms'] = 1000 * (latency + c.block_time + c.crossfade_time + .01
                + (min(c.crossfade_time, .04) if value else 0))

    @torch.inference_mode()
    def _process_audio(self, *args):
        started = time.perf_counter()
        super()._process_audio(*args)
        self.stats['infer_ms'] = (time.perf_counter() - started) * 1000
