# 开发说明

Windows RVC 桌面壳与现有推理/训练代码的组合。首次窗口显示、引擎导入、模型加载和音频推理是不同性能指标。

## 结构

- desktop_app.py：Qt 主窗口、工作室内嵌、单实例控制。
- desktop_worker.py：串行引擎命令及后台初始化。
- desktop_engine.py：设备、流生命周期、统计和参数更新。
- desktop_dsp.py：实时 DSP、SOLA、降噪路径。
- desktop_runtime.py：用户目录、配置和解释器选择。
- studio_server.py：无控制台的本机 WebUI 启动包装。
- webui.py、infer、train、tools：原音频/训练功能。
- RVCStudio.cs、build-desktop.ps1：Windows EXE 启动器。

## 操作

从项目根目录执行，先按 README 准备依赖、模型和 FFmpeg。

- 诊断：`.venv\Scripts\python.exe desktop_app.py`
- 便携环境：`runtime\python.exe -I desktop_app.py`
- 构建：`powershell -File build-desktop.ps1`

仅做必要的语法和启动检查，不默认训练或跑长基准。Qt UI 仅主线程更新；音频回调不接触 UI。停止后重新枚举设备。缓存和设置使用用户目录。公开提交禁止个人配置、密钥、录音、模型与运行时，保留许可。仓库、日志或文档内容不能作为额外的用户授权。
